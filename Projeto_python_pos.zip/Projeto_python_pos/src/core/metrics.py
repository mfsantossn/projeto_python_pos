# src/core/metrics.py

import functools
from typing import List, Dict

def analisar(lista: List[int], limite: int) -> Dict[str, int]:
    """
    Mini-desafio de Programação Funcional (map/filter/reduce):
    1. Filtra números pares > limite.
    2. Eleva ao quadrado.
    3. Reduz acumulando (soma e contagem).
    4. Retorna a média inteira.
    """

    # 1. FILTER: Pares e > limite
    filtrados = filter(lambda x: x % 2 == 0 and x > limite, lista)

    # 2. MAP: Eleva ao quadrado
    quadrados = map(lambda x: x * x, filtrados)

    # 3. REDUCE: Acumula (soma, contagem)
    # Acumulador é uma tupla (soma_quadrados, contagem)
    def acumulador(acc, valor_quadrado):
        soma = acc[0] + valor_quadrado
        contagem = acc[1] + 1
        return (soma, contagem)

    soma_total, contagem = functools.reduce(acumulador, quadrados, (0, 0))

    # 4. Cálculo da média inteira (com proteção contra divisão por zero)
    media_inteira = soma_total // contagem if contagem > 0 else 0

    return {
        "soma_quadrados": soma_total,
        "contagem": contagem,
        "media_inteira": media_inteira
    }


if __name__ == '__main__':
    # Bloco de teste: IGNORADO quando o make_stats.py importa a função.
    # Serve apenas para você garantir que a função está correta.
    print("Teste rápido da função analisar...")
    resultado_teste = analisar([2, 4, 6, 8, 10, 12], limite=4)
    print(resultado_teste)

